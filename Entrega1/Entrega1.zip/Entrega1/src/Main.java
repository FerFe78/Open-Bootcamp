public class Main {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.AdicionarPuerta();

        System.out.println(miCoche.puertas);

        suma(2,4,6);
    }
    public static void suma(int a, int b, int c){
        int resultado;
        resultado = a + b + c;

        System.out.println(resultado);
    }

}
class Coche {
    public int puertas = 2;

    public void AdicionarPuerta() {
        this.puertas++;
    }
}