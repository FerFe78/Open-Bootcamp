public class Main {
    public static void main(String[] args) {

        Persona persona = new Persona();
        persona.setEdad(25);
        persona.setNombre("José");
        persona.setTelefono("+51-11-1234-6578");

        System.out.println(persona.getNombre() +" "+ persona.getEdad()+" Tel "+ persona.getTelefono());

    }
}
class Persona {
    private int edad;
    private String nombre;
    private String telefono;

    public void setEdad(int edad){
        this.edad = edad;
    }
    public int getEdad() {
        return edad;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getNombre(){
        return nombre;
    }
    public void setTelefono(String telefono){
        this.telefono = telefono;
    }
    public String getTelefono(){
        return telefono;
    }
}